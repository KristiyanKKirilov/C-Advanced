﻿using System;

namespace CarManufacturer
{
    public class StartUp
    {
        static void Main()
        {           

            string make = Console.ReadLine();
            string model = Console.ReadLine();
            int year = int.Parse(Console.ReadLine());
            double fuelQuantity =  double.Parse(Console.ReadLine()); 
            double fuelConsumption = double.Parse(Console.ReadLine());
            Engine engine = new Engine(265, 2);
            Tire[] tires = new Tire[4]
            {
                new Tire(2020, 2.2),
                new Tire(2020, 2.2),
                new Tire(2020, 2.2),
                new Tire(2020, 2.2),
            };



            Car firstCar = new();
            Car secondCar = new(make, model, year);
            Car thirdCar = new(make, model, year, fuelQuantity, fuelConsumption);
            Console.WriteLine(thirdCar.Engine.HorsePower);
        }
    }

}