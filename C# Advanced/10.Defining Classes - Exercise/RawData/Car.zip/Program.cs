﻿using System;

namespace RawData
{
    internal class StartUp
    {
        static void Main(string[] args)
        {
            int carsCount = int.Parse(Console.ReadLine());
            List<Car> cars = new();

            for (int i = 0; i < carsCount; i++)
            {
                string[] carInfo = Console.ReadLine().Split(' ', StringSplitOptions.RemoveEmptyEntries);

                Car car = new Car(carInfo[0],
                                  int.Parse(carInfo[1]),
                                  int.Parse(carInfo[2]),
                                  int.Parse(carInfo[3]),
                                  carInfo[4],
                                  double.Parse(carInfo[5]),
                                  int.Parse(carInfo[6]),
                                  double.Parse(carInfo[7]),
                                  int.Parse(carInfo[8]),
                                  double.Parse(carInfo[9]),
                                  int.Parse(carInfo[10]),
                                  double.Parse(carInfo[11]),
                                  int.Parse(carInfo[12]));

                cars.Add(car);

            }
            string condition = Console.ReadLine();

            if (condition == "fragile")
            {
                foreach (Car currentCar in cars.Where(c=>c.Cargo.Type == "fragile"))
                {
                    foreach (var currentTire in currentCar.Tires)
                    {
                        if (currentTire.Pressure < 1)
                        {
                            Console.WriteLine(currentCar.Model);
                            return;
                        }
                    }
                }
            }
            else if (condition == "flammable")
            {
                foreach (Car currentCar in cars.Where(c => c.Cargo.Type == "flammable"))
                {
                    if (currentCar.Engine.Power > 250)
                    {
                        Console.WriteLine(currentCar.Model);                        
                    }

                }
            }
        }

    }
}