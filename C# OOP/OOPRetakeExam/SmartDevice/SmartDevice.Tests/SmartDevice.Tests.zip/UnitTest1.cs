namespace SmartDevice.Tests
{
    using NUnit.Framework;
    using System;
    using System.Text;

    public class Tests
    {
        [TestCase(100)]
        [TestCase(300)]
        public void ConstructorInitialize(int capacity)
        {
            Device device = new Device(capacity);
            ;
            Assert.AreEqual(capacity, device.MemoryCapacity);
            Assert.AreEqual(capacity, device.AvailableMemory);
            Assert.AreEqual(device.Photos, 0);
            Assert.That(device.Applications != null);

        }

        [TestCase(100)]
        [TestCase(300)]
        public void FormatDeviceWorking(int capacity)
        {
            Device device = new Device(capacity);
            device.FormatDevice();
            Assert.AreEqual(0, device.Photos);
            Assert.AreEqual(capacity, device.AvailableMemory);
            Assert.AreEqual(0, device.Photos);
            Assert.That(device.Applications != null);

        }



        [TestCase(100, "dad", 50)]
        [TestCase(130, "mom", 140)]
        public void AppWorking(int capacity, string appName, int appSize)
        {
            Device device = new Device(capacity);
            //Device device1 = new Device(capacity);

            device.InstallApp(appName, appSize);
            //device1.InstallApp(appName, appSize);

            Assert.AreEqual(50, device.AvailableMemory);
            Assert.IsTrue(device.Applications.Contains(appName));


           // Assert.Throws<InvalidOperationException>(() => device1.InstallApp(appName, appSize));
            //Assert.IsFalse(device1.Applications.Contains(appName));


        }
    }
}
